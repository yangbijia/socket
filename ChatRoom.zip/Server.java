package Ⱥ��;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

/**
 * ������
 * 
 * @author ybj
 *
 */
public class Server {

	Message message;

	public void getMsg(Message msg) {
		message = msg;
	}

	public static void main(String[] args) {
		Server server = new Server();
		server.startServer();
	}

	ServerSocket ss;
	List<ChatThread> allThread = new ArrayList<ChatThread>();

	public void startServer() {

		try {
			ss = new ServerSocket(8888);
			System.out.println("�������Ѵ򿪡���");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "����������ʧ��");

		}
		while (true) {
			try {
				// System.out.println("����������online=" + online);
				Socket accept = ss.accept();
				// System.out.println("�������Ѵ򿪡���online=" + online);
				ChatThread ct = new ChatThread(accept, this);

				System.out.println("thread.size=" + allThread.size());
				System.out.println("�������߳�");
				System.out.println(ct.socket.getInetAddress() + "���Ϸ���������");

				// System.out.println("ct.msg=" + ct.msg);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				JOptionPane.showMessageDialog(null, "�������쳣");
			}
		}

	}

	public synchronized void removeConnectionList(ChatThread c) {
		int index = 0;
		System.out.println("size=" + allThread.size());
		for (ChatThread ct : allThread) {
			if (ct == c) {
				System.out.println("�Ƴ�һ���߳�msg" + ct.msg);
				allThread.remove(allThread.indexOf(ct));
			}
			System.out.println("----index++=" + index++);
		}
		int j = 0;
		for (int i = 0; i < list.size() - j; i++) {
			if (Message.transferToMessage(c.msg).srcUser.equals(list.get(i))) {
				System.out.println("�Ƴ�һ���û�");
				list.remove(i);

				break;
			}
			System.out.println("----index++=" + j++);
		}
	}

	/**
	 * ������Ϣ�����пͻ���
	 * 
	 * @param msg
	 */
	List<String> list = new ArrayList<String>();

	public void sendMsgToAll(String msg) {
		// System.out.println("�㲥��Ϣname����=" + name);
		System.out.println("----msg=" + msg);
		Message m = Message.transferToMessage(msg);
		// Ⱥ����Ϣ
		if (m.type == 2) {
			for (ChatThread ct : allThread) {
				ct.sendMessage(msg);
			}
		}

		// ������Ϣ����
		if (m.type == 0) {
			String str = "";
			String s = "";
			int i = 0;
			for (i = 0; i < list.size(); i++) {
				if (list.get(i).equals(m.srcUser))
					break;
			}
			if (i == list.size()) {
				list.add(m.srcUser);
			}
			for (int j = 0; j < list.size(); j++) {
				str += list.get(j) + ":";
			}

			s = str.substring(0, str.length());
			System.out.println("�õ�s=" + s);
			for (ChatThread ct : allThread) {
				// ct.sendMessage(msg);
				Message mn = Message.transferToMessage(msg);
				mn.type = 1;
				mn.msg = s;
				String ms = mn.tranferString();
				System.out.println("�õ�ms=" + ms);
				ct.sendMessage(ms);
			}
		}

		// ������Ϣ����
		if (m.type == 3) {
			String str = "";
			String s = "";
			int i = 0;
			for (i = 0; i < list.size(); i++) {
				if (list.get(i).equals(m.srcUser)) {
					list.remove(i);
					break;
				}
			}
			for (int j = 0; j < list.size(); j++) {
				str += list.get(j) + ":";
			}
			s = str.substring(0, str.length());
			if ("".equals(s)) {
				s = "null";
			}
			// System.out.println("type=3�õ�s=" + s);
			for (ChatThread ct : allThread) {
				Message mn = Message.transferToMessage(msg);
				mn.type = 1;
				mn.msg = s;
				String ms = mn.tranferString();
				// System.out.println("type=3�õ�ms=" + ms);
				ct.sendMessage(ms);
			}
		}

		// ˽����Ϣ����
		if (m.type == 4) {
			String user;
			Message mn;
			System.out.println("m.destUser=" + m.destUser);
			StringBuffer destUser = new StringBuffer(m.destUser);
			int index = destUser.indexOf(":");
			while (index != -1) {
				user = destUser.substring(0, index);
				destUser.delete(0, index + 1);
				for (ChatThread ct : allThread) {
					mn = Message.transferToMessage(ct.msg);
					if (mn.srcUser.equals(user)) {
						Message me = Message.transferToMessage(msg);
						me.type = 2;
						System.out.println("me.tranferString()="
								+ me.tranferString());
						ct.sendMessage(me.tranferString());
					}
					// System.out.println("server=" + ct.msg);
				}
				index = destUser.indexOf(":");
			}

		}

	}
}
