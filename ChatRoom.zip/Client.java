package Ⱥ��;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JOptionPane;

/**
 * 
 * @author ybj
 *
 */
public class Client extends Thread {

	String str = "";
	Message message;
	Socket socket;
	ChatFrame ct;
	BufferedReader br;
	BufferedWriter bw;
	Thread thread;
	int flag = 0;
	boolean temp = false;

	// boolean connect=false;

	public Client(Message message, ChatFrame ct) {
		super();
		this.message = message;
		this.ct = ct;
	}

	public void Connect(Socket socket) {

		try {
			temp = true;
			InputStream is = socket.getInputStream();
			System.out.println("��ȡ������");
			InputStreamReader isr = new InputStreamReader(is);
			br = new BufferedReader(isr);

			OutputStream os = socket.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			bw = new BufferedWriter(osw);
			System.out.println("������Ϣ" + message.tranferString());
			bw.write(message.tranferString());
			bw.newLine();
			bw.flush();
			thread = new Thread(this);
			thread.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			temp = false;
		}
	}

	public void Connect(int port) {

		try {
			flag = 0;
			System.out.println("message.destUser=" + message.destUser);
			socket = new Socket("127.0.0.1", port);

			temp = true;
			InputStream is = socket.getInputStream();
			// System.out.println("��ȡ������");
			InputStreamReader isr = new InputStreamReader(is);
			br = new BufferedReader(isr);

			OutputStream os = socket.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			bw = new BufferedWriter(osw);
			// System.out.println("������Ϣ" + message.tranferString());
			bw.write(message.tranferString());
			bw.newLine();
			bw.flush();
			System.out.println("������Ϣ" + message.tranferString());
			// System.out.println("��ȡ�����");

			thread = new Thread(this);
			thread.start();

			// System.out.println("�������߳�");
			flag = 1;

		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			temp = false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			temp = false;
		}
	}

	// ����������ʷ��¼
	@Override
	public void run() {
		try {
			while (temp) {
				str = br.readLine();
				System.out.println("������Ϣbr.read=" + str);
				String s = str.substring(0, str.length());

				System.out.println("������Ϣstr=" + str);
				Message msg = Message.transferToMessage(str);

				if (msg.type == 1) {
					if (!msg.msg.equals("null")) {
						ct.updateList(msg.msg);
					}
				} else {
					ct.showAllMsg(msg);
					System.out.println("׷����Ϣ");
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "���շ�������Ϣ�쳣");
		}
	}

	/**
	 * �Ͽ�����
	 */
	public void disconnect(int port) {
		// if (socket != null) {
		try {
			flag = 0;
			// System.out.println("message.destUser=" + message.destUser);
			Socket socket = new Socket("127.0.0.1", port);

			temp = true;
			InputStream is = socket.getInputStream();
			System.out.println("��ȡ������");
			InputStreamReader isr = new InputStreamReader(is);
			br = new BufferedReader(isr);

			System.out.println("��ȡ�����");

			OutputStream os = socket.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			bw = new BufferedWriter(osw);
			ct.message.type = 3;
			ct.extractMessage(ct.message);
			bw.write(ct.message.tranferString());
			bw.newLine();
			bw.flush();
			System.out.println("����������Ϣ" + message.tranferString());

			thread = new Thread(this);
			thread.start();

			// System.out.println("�������߳�");
			// flag = 1;
			// temp = false;

			thread = null;
			// socket.close();
		} catch (IOException io) {
			io.printStackTrace();
		}
		socket = null;
		ct.jta_show.setText("");
		// ct.jta_user.setText("");
		ct.model.clear();
	}
	// }

}
