package Ⱥ��;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * ���촰��
 * 
 * @author ybj
 *
 */
public class ChatFrame extends JFrame {

	JTextArea jta_show;
	JScrollPane jsp_show;
	// JTextArea jta_user;
	DefaultListModel model;
	JList lis_user;
	JScrollPane jsp_user;
	JTextArea jta_send;
	JScrollPane jsp_send;
	Message message;
	String ip, name;
	int port;
	ChatFrame chatFrame = this;
	List<String> userList = new ArrayList<String>();
	Client client;

	public static void main(String[] args) {
		ChatFrame login = new ChatFrame("", "", 8888);
		login.initFrame();
	}

	public ChatFrame(String ip, String name, int port) {
		super();
		this.ip = ip;
		this.name = name;
		this.port = port;
	}

	public void initFrame() {
		this.setTitle("�û�" + name + "���촰��");
		this.setSize(590, 560);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
		// this.setUndecorated(true);//�ޱ߿�

		JPanel jp1 = new JPanel();
		jp1.setPreferredSize(new Dimension(360, 550));
		JPanel jp2 = new JPanel();
		jp2.setPreferredSize(new Dimension(160, 550));

		jta_show = new JTextArea(16, 30);
		jsp_show = new JScrollPane(jta_show);
		// jta_user = new JTextArea(25, 14);
		model = new DefaultListModel();
		lis_user = new JList(model);
		for (int i = 0; i < 10; i++) {
			model.addElement("=====" + i + i + "-----");
		}
		lis_user.setVisibleRowCount(15);
		lis_user.setFixedCellWidth(135);
		lis_user.setBorder(BorderFactory.createTitledBorder("�û��б�"));
		jsp_user = new JScrollPane(lis_user);
		jta_send = new JTextArea(9, 30);
		jsp_send = new JScrollPane(jta_send);
		JButton bt = new JButton("����");
		JButton _bt = new JButton("ע����¼");
		JRadioButton jrb_all = new JRadioButton("Ⱥ��");
		JRadioButton jrb_select = new JRadioButton("������");
		ButtonGroup bg = new ButtonGroup();
		bg.add(jrb_all);
		bg.add(jrb_select);

		ActionListener al = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				if (e.getSource() == bt) {

					if (jrb_select.isSelected()) {
						System.out.println("ѡ������Ϣ");
						sendMsg(4, null);
					} else {
						System.out.println("��ͨ������Ϣ");
						sendMsg(2, null);
					}
				}
				if (e.getSource() == _bt) {
					// if (client.flag == 1)
					client.disconnect(port);
					close();
					// else
					// JOptionPane.showMessageDialog(null, "����ʧ��");
				}
			}
		};

		this.add(jp1);
		this.add(jp2);
		jp1.add(jsp_show);
		jp1.add(jsp_send);
		jp1.add(bt);
		jp1.add(_bt);
		jp2.add(jsp_user);
		jp2.add(jrb_all);
		jp2.add(jrb_select);

		bt.addActionListener(al);
		_bt.addActionListener(al);

		this.setVisible(true);
	}

	public void sendMsg(int TYPE, Socket socket) {

		SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd hh:mm:ss");
		String dateStr = sdf.format(System.currentTimeMillis());
		try {
			int type = TYPE;
			Date date = sdf.parse(dateStr);
			String srcUser = name;
			String destUser = ip;
			String msg = jta_send.getText();
			message = new Message(type, date, srcUser, destUser, msg);
			this.extractMessage(message);
			jta_send.setText("");
			System.out.println("������Ϣ" + message.tranferString());
			client = new Client(message, this);
			if (type != 0)
				client.Connect(port);
			else
				client.Connect(socket);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("������Ϣʧ��");
		}

	}

	public Message extractMessage(Message message) {

		if (message.type == 0) {
			message.msg = name + "������������\n";
		} else if (message.type == 1)
			updateList(message.msg);
		else if (message.type == 3)
			message.msg = name + "�뿪����������\n";
		else if (message.type == 4) {
			int[] user = lis_user.getSelectedIndices();
			message.destUser = "";
			for (int i : user)
				message.destUser += model.get(i) + ":";
			System.out.println("destUser=" + message.destUser);
		}
		return message;
	}

	public void updateList(String line) {
		userList.clear();
		// jta_user.setText("");
		model.clear();
		// System.out.println("������Ϣline" + line);
		StringBuffer str = new StringBuffer(line);
		// for (int i = 0; i < userList.size(); i++)
		// userList.get(i) = "";
		int index = str.indexOf(":");
		while (index != -1) {
			userList.add(str.substring(0, index));
			str.delete(0, index + 1);
			// str.substring(index 1);
			index = str.indexOf(":");
		}
		for (int i = 0; i < userList.size(); i++)
			// jta_user.append(userList.get(i) + "\n");
			model.addElement(userList.get(i));
	}

	public void showAllMsg(Message msg) {
		// String[] string = msg.split("\\|");
		jta_show.append("ʱ�䣺" + msg.date + "  �û���" + msg.srcUser
				+ "\r\n������Ϣ��\r\n" + msg.msg + "\r\n");
	}

	public void close() {
		this.dispose();
	}

}
