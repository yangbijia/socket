package Ⱥ��;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

import javax.swing.JOptionPane;

/**
 * 
 * @author ybj
 *
 */
public class ChatThread extends Thread {

	Socket socket;
	BufferedWriter bw;
	BufferedReader br;
	String msg = "";
	String name = "";
	Server ser;

	public ChatThread(Socket socket, Server ser) {
		super();
		this.socket = socket;
		this.ser = ser;

		this.start();
	}

	@Override
	public void run() {
		try {

			FileOutputStream fos = new FileOutputStream(
					"C:\\Users\\Administrator\\Desktop\\record.txt", true);

			FileInputStream fis = new FileInputStream(
					"C:\\Users\\Administrator\\Desktop\\record.txt");
			InputStreamReader fisr = new InputStreamReader(fis);
			BufferedReader fbr = new BufferedReader(fisr);

			InputStream is = socket.getInputStream();
			System.out.println("��������ȡ������");
			InputStreamReader isr = new InputStreamReader(is);
			br = new BufferedReader(isr);

			OutputStream os = socket.getOutputStream();
			System.out.println("��������ȡ�����");
			OutputStreamWriter osw = new OutputStreamWriter(os);
			bw = new BufferedWriter(osw);
			msg = br.readLine();
			// System.out.println("����һ����Ϣ");
			System.out.println("msg=" + msg);
			if (msg != null && msg != "") {
				System.out.println("msg�ǿ�");
				Message mesg = Message.transferToMessage(msg);
				// ���û��̼߳����б�
				if (Message.transferToMessage(msg).type == 0) {
					System.out.println("���ӽ���");
					ser.allThread.add(this);
				}
				// ��ȡ��ʷ��¼
				String read;
				while ((read = fbr.readLine()) != null) {
					System.out.println("\nooread=" + read);
					ser.sendMsgToAll(read);
					System.out.println("wancheng");
				}
				if (mesg.type != 1) {
					// ����Ϣд���ļ�
					mesg.type = 2;
					byte[] b = (mesg.tranferString() + "\r\n").getBytes();
					int len = b.length;
					fos.write(b, 0, len);
				}
				// for (ChatThread ct : ser.allThread) {
				//
				// System.out.println("chat=" + ct.msg);
				// }
				// ������Ϣ��������
				ser.sendMsgToAll(msg);
			}
			System.out.println();
			// System.out.println("last str=" + str);
			// }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "������������Ϣʧ��");
		}

	}

	public void sendMessage(String msg) {

		try {
			bw.write(msg);
			bw.newLine();
			// bw.reset();
			System.out.println("��������������Ϣ");
			bw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "��������������ʧ��");
		}
	}
}
