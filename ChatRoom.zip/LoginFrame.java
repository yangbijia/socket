package Ⱥ��;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * login frame
 * 
 * @author ybj
 *
 */
public class LoginFrame extends JFrame {

	// 127.0.0.1:8888 172.27.35.2/8888

	int flag = 0;
	ChatFrame cf;

	public static void main(String[] args) {
		LoginFrame login = new LoginFrame();
		login.initFrame();
	}

	public void initFrame() {
		this.setTitle("��½����");
		this.setSize(350, 250);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(new FlowLayout(1, 20, 20));

		JPanel jp = (JPanel) this.getContentPane();
		this.setContentPane(jp);
		jp.setOpaque(false);
		ImageIcon img = new ImageIcon("image/login.jpg");
		JLabel lb = new JLabel(img);
		lb.setBounds(0, 0, this.getWidth() - 5, this.getHeight() - 10);
		this.getLayeredPane().add(lb, new Integer(Integer.MIN_VALUE));
		// this.getLayeredPane().setLayout(null);

		// containPane
		JLabel lb_ip = new JLabel("IP��ַ+�˿ں�");
		JTextField tf = new JTextField(16);
		tf.setText("127.0.0.1:8888");
		JLabel lb_tip = new JLabel(
				"                                          (  ����   192.168.1.101:2300  )");
		JLabel lb_user = new JLabel("�û���");
		JTextField tf_user = new JTextField(16);
		tf_user.setText("С��");
		JButton bt_login = new JButton("��¼");

		ActionListener al = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String[] string = tf.getText().split(":");
				// System.out.println("string[0]=" + string[0] + "string[1]="
				// + string[1]);
				if (e.getSource() == bt_login) {

					if (login(string[0], Integer.parseInt(string[1])) == 1) {

						cf = new ChatFrame(string[0], tf_user.getText(),
								Integer.parseInt(string[1]));
						// System.out.println(tf.getText());
						cf.initFrame();
						cf.sendMsg(0, socket);
						// Server.online = true;
						closeFrame();
					} else {
						JOptionPane.showInputDialog(this, "��¼ʧ��");
					}
				}
			}

		};
		bt_login.addActionListener(al);
		this.add(lb_ip);
		this.add(tf);
		this.add(lb_tip);
		this.add(lb_user);
		this.add(tf_user);
		this.add(bt_login);
		this.setVisible(true);
	}

	Socket socket;

	public int login(String s1, int s2) {
		try {
			flag = 0;
			socket = new Socket(s1, s2);
			flag = 1;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "����ת���쳣");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "IP��˿��쳣");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "IO�쳣");
		}
		return flag;
	}

	public void closeFrame() {
		this.dispose();
	}

}
