package Ⱥ��;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * ��װ�õ���Ϣ��
 * 
 * @author ybj
 *
 */
public class Message {
	int type;
	Date date;
	String srcUser;
	String destUser;
	String msg;

	public Message(int type, Date date, String srcUser, String destUser,
			String msg) {
		super();
		this.type = type;
		this.date = date;
		this.srcUser = srcUser;
		this.destUser = destUser;
		this.msg = msg;
	}

	public static Message transferToMessage(String msg) {

		int newType = 0;
		Date newDate = null;
		String newSrcUser = null;
		String newDestUser = null;
		String newMsg = null;
		try {
			String[] string = msg.split("\\|");
			newType = Integer.parseInt(string[0]);
			SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd hh:mm:ss");
			newDate = sdf.parse(string[1]);
			newSrcUser = string[2];
			newDestUser = string[3];
			newMsg = string[4];

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new Message(newType, newDate, newSrcUser, newDestUser, newMsg);
	}

	public String tranferString() {
		SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd hh:mm:ss");
		String dateStr = sdf.format(System.currentTimeMillis());
		StringBuffer sb = new StringBuffer();
		sb.append(type + "");
		sb.append("|");
		sb.append(dateStr);
		sb.append("|");
		sb.append(srcUser);
		sb.append("|");
		sb.append(destUser);
		sb.append("|");
		sb.append(msg);

		return sb.toString();
	}

}
